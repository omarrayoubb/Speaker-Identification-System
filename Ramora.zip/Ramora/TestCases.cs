﻿using Microsoft.SqlServer.Server;
using Recorder.MFCC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Windows.Forms;

namespace Recorder.Ramora
{
    public static class TestCases
    {
        public static void Test_Pruning(string path, string tempPath, int Pruning_Width)
        {
            if (Pruning_Width < 0)
            {
                Console.WriteLine("Error: pruning must be bigger than or equal to 0 ");
            }

            AudioSignal audio = new AudioSignal(), audio2 = new AudioSignal();
            audio = AudioOperations.OpenAudioFile(path);

            audio = AudioOperations.RemoveSilence(audio);
            audio2 = AudioOperations.OpenAudioFile(tempPath);
            audio2 = AudioOperations.RemoveSilence(audio2);
            Sequence inn = AudioOperations.ExtractFeatures(audio);
            Sequence outt = AudioOperations.ExtractFeatures(audio2);
            Stopwatch stopwatch = new Stopwatch();

            DTW Answer = new DTW("", double.MaxValue);

            stopwatch = Stopwatch.StartNew();
            double distance = Answer.DTW_with_pruning_by_search_paths(inn, outt, inn.Frames.Length, outt.Frames.Length, Pruning_Width);
            stopwatch.Stop();
            Console.WriteLine("Time elapsed = " + (double)stopwatch.ElapsedMilliseconds);
            Console.WriteLine("Distance = " + distance);
        }

        public static void load_complete_tests(int complete_test_Cases)
        {

            switch (complete_test_Cases)
            {
                case 1:
                    load_small();
                    break;
                case 2:
                    load_medium();
                    break;
                case 3:

                    break;
            }
        }
        private static void load_small()
        {
            string path1 = @"C:\Users\DELL\Desktop\SPEAKER ID\[2] SPEAKER IDENTIFICATION\TEST CASES\[2] COMPLETE\Case1\Small samples\TrainingList.txt";
            string path2 = @"C:\Users\DELL\Desktop\SPEAKER ID\[2] SPEAKER IDENTIFICATION\TEST CASES\[2] COMPLETE\Case1\Small samples\TestingList5Samples.txt";
            int pruning = 23;
            Stopwatch stopwatch = new Stopwatch();
            Stopwatch stopwatch2 = new Stopwatch();
            List<User> users = new List<User>();
            stopwatch = Stopwatch.StartNew();
            users = TestcaseLoader.LoadTestcase1Testing(path2);
            stopwatch.Stop();
            List<User> Users = new List<User>();
            stopwatch2 = Stopwatch.StartNew(); 

            Users = TestcaseLoader.LoadTestcase1Training(path1);
            stopwatch2.Stop();
            
            List<Temp> test = new List<Temp>();
            List<Temp> train = new List<Temp>();

            stopwatch.Start();
            foreach (var i in users)
            {
                foreach (var x in i.UserTemplates)
                {
                    Temp temp = new Temp();
                    temp.name = i.UserName;
                    Sequence seq = new Sequence();
                    seq = AudioOperations.ExtractFeatures(x);
                    temp.Seq = seq;
                    test.Add(temp);
                }
            }
            stopwatch.Stop();
            stopwatch2.Start();
            foreach (var i in Users)
            {
                foreach (var x in i.UserTemplates)
                {
                    Temp temp = new Temp();
                    temp.name = i.UserName;
                    temp.Seq = AudioOperations.ExtractFeatures(x);
                    train.Add(temp);
                }
            }
            stopwatch2.Stop();
            Stopwatch stopwatchMatching = new Stopwatch();
            Stopwatch stopwatchMatching2 = new Stopwatch();

            stopwatch.Start();
            int accurracy = 0;
            int accurracyWith = 0;
            for (int i = 0; i < test.Count; i++)
            {
                DTW bestwithout = new DTW("", double.MaxValue);
                DTW bestwith = new DTW("", double.MaxValue);
                for (int j = 0; j < train.Count; j++)
                {
                    DTW d = new DTW(train[j].name, double.MaxValue);
                    DTW t = new DTW(train[j].name, double.MaxValue);
                    if (test[i].Seq == null || train[j].Seq == null) continue;
                    stopwatchMatching.Start();
                    double without = d.DTW_without_pruning(test[i].Seq, train[j].Seq, test[i].Seq.Frames.Length, train[j].Seq.Frames.Length);
                    stopwatchMatching.Stop();
                    stopwatchMatching2.Start();
                   double with= t.DTW_with_pruning_by_search_paths(test[i].Seq, train[j].Seq, test[i].Seq.Frames.Length, train[j].Seq.Frames.Length, pruning);
                    stopwatchMatching2.Stop();
                    if (without <= bestwithout.getVal())
                    {
                        bestwithout = d;
                    }
                    if (with <= bestwith.getVal())
                    {
                        bestwith = t;
                    }
                    
                }
                accurracy += (bestwithout.getname() == test[i].name ? 1 : 0);
                accurracyWith += (bestwith.getname() == test[i].name ? 1 : 0);

            }
            stopwatch.Stop();
            double acc1 = (double)accurracy / (double)test.Count;
            double acc2 = (double)accurracyWith / (double)test.Count;
            Console.WriteLine("Accurracy of DTW Without Pruning = " + acc1 * 100.0);
            Console.WriteLine("Accurracy of DTW With Pruning = " + acc2 * 100.0);
            Console.WriteLine("Time elapsed in Load And Extract test Files and DTW With and without Pruning " + stopwatch.Elapsed);
            Console.WriteLine("Time elapsed in matching DTW without PRunig " + stopwatchMatching.Elapsed);
            Console.WriteLine("Time elapsed in matching DTW with pruning " + stopwatchMatching2.Elapsed);


        }
        private static void load_medium()
        {
            string path1 = @"C:\Users\DELL\Desktop\SPEAKER ID\[2] SPEAKER IDENTIFICATION\TEST CASES\[2] COMPLETE\Case2\Medium samples\TestingList1Sample.txt";
            string path2 = @"C:\Users\DELL\Desktop\SPEAKER ID\[2] SPEAKER IDENTIFICATION\TEST CASES\[2] COMPLETE\Case2\Medium samples\TrainingList5Samples.txt";
            int pruning = 55;
            Stopwatch stopwatch = new Stopwatch();
            Stopwatch stopwatch2 = new Stopwatch();
            List<User> users = new List<User>();
            stopwatch = Stopwatch.StartNew();
            users = TestcaseLoader.LoadTestcase1Testing(path1);
            stopwatch.Stop();
            List<User> Users = new List<User>();
            stopwatch2 = Stopwatch.StartNew();

            Users = TestcaseLoader.LoadTestcase1Training(path2);
            stopwatch2.Stop();

            List<Temp> test = new List<Temp>();
            List<Temp> train = new List<Temp>();

            stopwatch.Start();
            foreach (var i in users)
            {
                foreach (var x in i.UserTemplates)
                {
                    Temp temp = new Temp();
                    temp.name = i.UserName;
                    Sequence seq = new Sequence();
                    seq = AudioOperations.ExtractFeatures(x);
                    temp.Seq = seq;
                    test.Add(temp);
                }
            }
            stopwatch.Stop();
            stopwatch2.Start();
            foreach (var i in Users)
            {
                foreach (var x in i.UserTemplates)
                {
                    Temp temp = new Temp();
                    temp.name = i.UserName;
                    temp.Seq = AudioOperations.ExtractFeatures(x);
                    train.Add(temp);
                }
            }
            stopwatch2.Stop();
            Stopwatch stopwatchMatching = new Stopwatch();
      

            stopwatch.Start();
            int accurracy = 0;
            int accurracyWith = 0;
            for (int i = 0; i < test.Count; i++)
            {
                DTW bestwithout = new DTW("", double.MaxValue);
                DTW bestwith = new DTW("", double.MaxValue);
                for (int j = 0; j < train.Count; j++)
                {
                    DTW d = new DTW(train[j].name, double.MaxValue);
                    DTW t = new DTW(train[j].name, double.MaxValue);
                    if (test[i].Seq == null || train[j].Seq == null) continue;
                    stopwatchMatching.Start();                    
                    double with = t.DTW_with_pruning_by_search_paths(test[i].Seq, train[j].Seq, test[i].Seq.Frames.Length, train[j].Seq.Frames.Length, pruning);
                    stopwatchMatching.Stop();
                    
                    
                    if (with < bestwith.getVal())
                    {
                        bestwith = t;
                    }

                }
                
                accurracyWith += (bestwith.getname() == test[i].name ? 1 : 0);
                Console.WriteLine(bestwith.getname() == test[i].name ? 1 : 0);

            }
            stopwatch.Stop();
            double acc1 = (double)accurracy / (double)test.Count;
            double acc2 = (double)accurracyWith / (double)test.Count;
            Console.WriteLine(accurracyWith);
            Console.WriteLine("Accurracy of DTW Without Pruning = " + acc1 * 100.0);
            Console.WriteLine("Accurracy of DTW With Pruning = " + acc2 * 100.0);
            Console.WriteLine("Time elapsed in Load And Extract test Files and DTW With and without Pruning " + stopwatch.Elapsed);
            Console.WriteLine("Time elapsed in matching DTW with Pruning " + stopwatchMatching.Elapsed);
         

        
        }
    }
}
